create view v_top_paid_employee1 as
select `hospital`.`employees`.`id`            AS `id`,
       `hospital`.`employees`.`first_name`    AS `first_name`,
       `hospital`.`employees`.`last_name`     AS `last_name`,
       `hospital`.`employees`.`job_title`     AS `job_title`,
       `hospital`.`employees`.`department_id` AS `department_id`,
       `hospital`.`employees`.`salary`        AS `salary`
from `hospital`.`employees`
order by `hospital`.`employees`.`salary` desc;

