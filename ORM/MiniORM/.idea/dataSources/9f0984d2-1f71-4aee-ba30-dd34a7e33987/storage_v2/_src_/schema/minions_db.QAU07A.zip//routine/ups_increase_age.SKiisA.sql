create
    definer = root@localhost procedure ups_increase_age(IN id int)
BEGIN
UPDATE minions
SET age = age + 1
WHERE id = id;
END;

