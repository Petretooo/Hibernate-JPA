create
    definer = root@localhost function udf_client_cards_count(name varchar(30)) returns int
BEGIN 
	DECLARE cards_count INT;
    SET cards_count := (
		SELECT count(*)
		FROM clients AS cl 
		INNER JOIN bank_accounts as ba
		ON ba.client_id = cl.id
		INNER JOIN cards as c
		on ba.id = c.bank_account_id
		GROUP BY cl.full_name
		HAVING cl.full_name = name
	);
    RETURN cards_count;
END;

