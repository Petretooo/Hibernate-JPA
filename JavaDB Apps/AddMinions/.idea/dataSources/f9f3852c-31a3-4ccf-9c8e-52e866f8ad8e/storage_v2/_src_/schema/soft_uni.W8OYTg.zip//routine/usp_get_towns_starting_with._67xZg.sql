create
    definer = root@localhost procedure usp_get_towns_starting_with(IN str_start varchar(10))
BEGIN
	SELECT name AS town_name
    FROM towns
    WHERE name LIKE CONCAT(str_start, '%')
    ORDER BY town_name;
END;

