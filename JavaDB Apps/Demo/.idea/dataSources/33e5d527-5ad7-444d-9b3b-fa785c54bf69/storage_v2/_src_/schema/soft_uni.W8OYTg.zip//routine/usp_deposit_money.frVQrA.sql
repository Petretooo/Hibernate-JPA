create
    definer = root@localhost procedure usp_deposit_money(IN account_id int, IN money_amount double)
BEGIN
START TRANSACTION;
UPDATE accounts
SET balance = balance + money_amount
WHERE id = account_id;
IF((SELECT COUNT(*)
	FROM accounts
    WHERE id = account_id) != 1) THEN
    ROLLBACK;
    ELSEIF(money_amount <= 0) THEN
    ROLLBACK;
    ELSE 
    COMMIT;
    END IF;
END;

