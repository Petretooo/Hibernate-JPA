create
    definer = root@localhost function ufn_calculate_future_value(init_sum int, rate double(10, 2), years int) returns double(10, 2)
BEGIN
	DECLARE future_value DOUBLE(10,2);
    
    SET future_value := init_sum * POW(1 + rate, years);
    
    RETURN future_value;
END;

