create
    definer = root@localhost function ufn_is_word_comprised(letters varchar(50), word varchar(50)) returns int
BEGIN 
	DECLARE indx INT;
    DECLARE symbol VARCHAR(1);
    SET indx := 1;
    WHILE indx < CHAR_LENGTH(word)  DO
		SET symbol := SUBSTRING(word, indx, 1);
        IF LOCATE(symbol, letters) = 0 THEN
			RETURN 0;
		END IF;
        SET indx := indx + 1;
	END WHILE;
    RETURN 1;
END;

