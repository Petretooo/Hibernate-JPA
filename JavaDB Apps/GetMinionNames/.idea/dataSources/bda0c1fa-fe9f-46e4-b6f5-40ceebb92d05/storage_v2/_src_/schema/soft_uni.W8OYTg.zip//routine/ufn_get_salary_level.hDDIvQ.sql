create
    definer = root@localhost function ufn_get_salary_level(salary double(10, 4)) returns varchar(10)
BEGIN
	DECLARE result VARCHAR(10);
    IF (salary < 30000) THEN SET result := 'Low';
    ELSEIF (salary BETWEEN 30000 AND 50000) THEN SET result := 'Average';
    ELSEIF (salary > 50000) THEN SET result := 'High';
    END IF;
    
    RETURN result;
END;

