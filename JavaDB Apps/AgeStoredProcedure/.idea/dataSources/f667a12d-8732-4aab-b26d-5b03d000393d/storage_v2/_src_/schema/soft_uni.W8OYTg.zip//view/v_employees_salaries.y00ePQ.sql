create definer = root@localhost view v_employees_salaries as
select `soft_uni`.`employees`.`first_name` AS `first_name`,
       `soft_uni`.`employees`.`last_name`  AS `last_name`,
       `soft_uni`.`employees`.`salary`     AS `salary`
from `soft_uni`.`employees`;

