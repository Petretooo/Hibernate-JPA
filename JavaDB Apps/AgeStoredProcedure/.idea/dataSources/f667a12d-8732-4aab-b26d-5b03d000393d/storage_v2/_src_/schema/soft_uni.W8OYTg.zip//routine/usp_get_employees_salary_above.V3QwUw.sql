create
    definer = root@localhost procedure usp_get_employees_salary_above(IN num_salary int)
BEGIN
	SELECT first_name, last_name
    FROM employees
    WHERE salary >= num_salary
    ORDER BY first_name, last_name, employee_id DESC;
END;

