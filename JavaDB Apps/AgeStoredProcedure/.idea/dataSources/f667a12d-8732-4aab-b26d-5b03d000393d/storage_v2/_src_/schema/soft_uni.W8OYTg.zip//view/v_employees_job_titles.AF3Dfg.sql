create definer = root@localhost view v_employees_job_titles as
select concat(`e`.`first_name`, ' ', ifnull(`e`.`middle_name`, ''), ' ', `e`.`last_name`) AS `full_name`,
       `e`.`job_title`                                                                    AS `job_title`
from `soft_uni`.`employees` `e`;

