create
    definer = root@localhost procedure ups_lower_name(IN id int)
BEGIN
UPDATE minions
SET name = lower(name)
WHERE id = id;
END;

